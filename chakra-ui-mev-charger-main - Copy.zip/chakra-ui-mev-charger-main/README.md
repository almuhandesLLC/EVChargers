EV chargers website created with chakra ui
